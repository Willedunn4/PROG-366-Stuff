﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WDTimeComplexity
{
    public class TimeComplexityExamples
    {
        //constant time O(1)
        public int GetFirstElement(int[] arr)
        {
            return arr[0];
        }

        //Linear time O(n)
        public void PrintElements(int[] arr)
        {
            foreach (int element in arr)
            {
                Console.WriteLine(element);
            }
         
        }
        //Quadratic Time O(n2)

        public void PrintPairs(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr.Length; j++)
                {
                    Console.WriteLine(arr[i]+ ","+arr[j]);
                }
            }
        }
    }
}
